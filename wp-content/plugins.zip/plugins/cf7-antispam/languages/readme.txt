Translations have moved to
https://translate.wordpress.org/projects/wp-plugins/cf7antispam

Thank you for your contribution.