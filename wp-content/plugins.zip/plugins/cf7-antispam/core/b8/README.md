# b8

## A statistical spam filter implemented in PHP

b8 is a statistical ("Bayesian") spam filter implemented in PHP. It is intended to keep your weblog or guestbook spam-free. The filter can be used anywhere in your PHP code and tells you whether a text is spam or not, using statistical text analysis.

## Homepage

The project's official homepage with further information is <https://nasauber.de/opensource/b8/>.
